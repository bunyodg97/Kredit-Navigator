# Kredit Navigator V4.5

Kredit, to'lov, eslatma va hisob-kitoblarni **qurilmada** (oflayn) boshqarish ilovasi. Veb-versiya + Android (WebView) o'rami.

## Tuzilma
| Papka | Mazmuni |
|---|---|
| `web/` | **Yagona manba**: `index.html`, `assets/` (JS/CSS, logotiplar). Android ham shu papkani ishlatadi |
| `web/assets/core.js` | Yadro: kreditlar, sana, qoldiq, CSV, shifrlash, zaxira (`window.KNC`) |
| `app/` | Android loyihasi (`assets.srcDirs = ['../web']`) |
| `Windows/` | `Kredit_Navigator_Start.bat` – veb-versiyani brauzerda ochadi (EXE emas) |
| `tests/` | `core.test.js` (Node), `e2e_flow.py` (Playwright + Chrome) |
| `design/` | Katta original rasmlar (APK ga kirmaydi) |

## Ishga tushirish
- **Veb:** `web/index.html` ni oching (yoki Windowsda `.bat`).
- **Android APK:** repozitoriyga yuklab, GitHub → Actions → *Build Kredit Navigator APK* → Run workflow. Natija: `Kredit-Navigator-V4_5-debug-APK` (debug imzo, Play Store uchun emas).
- **Testlar:** `node --test` · brauzer testi: `pip install playwright && python3 tests/e2e_flow.py`

## V4.5 da tuzatilganlar
**Android:** `WebChromeClient` (alert/confirm/prompt va fayl tanlash), Blob/data yuklab olishlar `saveFile` ko'prigi orqali *Yuklashlar* papkasiga, ilova belgisi va bildirishnoma belgisi, status/navigatsiya paneli chekkalari (targetSdk 35), alarm soni 400 bilan cheklangan va ikkala `set…` chaqiruvi himoyalangan.
**Ma'lumot:** kredit ID lari satrga keltirildi (to'lovlar daftari va tahrirlash endi bank tanlash orqali qo'shilgan kreditlar bilan ishlaydi), "birinchi to'lov sanasi" yagona maydon, oy oxiri (29–31) to'g'ri qisqartiriladi, eski V3 cheklari yagona daftarga ko'chiriladi.
**Hisob:** dashboard qoldig'i qayd etilgan to'lovlar asosida kamayadi; alohida sug'urta jamiga qo'shiladi; differensial to'lov to'g'ri ko'rsatiladi; tavsiya, solishtirish va eslatmalar kredit tanlash orqali ishlaydi; demo qiymatlar olib tashlandi; grafik o'qlari, taqvim va "keyingi to'lov" dinamik.
**Zaxira/xavfsizlik:** zaxira barcha ma'lumotni qamraydi (kreditlar, daftar, cheklar, eslatmalar, shifrlangan ID lar); shifrlash katta fayllarda qulamaydi; yagona shifrlangan format (eski formatlar ham tiklanadi), parol ≥10 belgi; "hammasini o'chirish" haqiqatan hammasini o'chiradi; inline `onclick` orqali kod kiritish yo'li yopildi; ID himoyasida parol tasdig'i; zaxira fayli tekshiriladi.
**CSV:** `,` `;` tab, `18.12.2026` va `2026-12-18`, `904.831` / `904 831,50` qabul qilinadi; takrorlar o'tkazib yuboriladi; nechta qator o'qilmagani ko'rsatiladi.
**Tuzilma:** `assets` takrori yo'q, versiyalar bir xil, takroriy bo'limlar (cheklar, shifrlangan kabinet, eslatmalar, PDF skaner) birlashtirildi, `bank-list.json` olib tashlandi, katta rasmlar APK dan chiqarildi, logotiplar kesilib oq plitkada ko'rsatiladi, 10 ta qo'shimcha bank (logosiz) qo'shildi.

**Tema:** barcha ranglar `assets/theme-v43.css` dagi CSS o'zgaruvchilarda (`--h`, `--sum`, `--note`, `--btn`, `--err`); eski `ui-fixes` fayllaridagi alohida ranglar olib tashlandi. Yangi komponent qo'shsangiz, rangni shu o'zgaruvchilardan oling.

## Ma'lum cheklovlar
- Manrope shrifti ilova ichiga qo'shilmagan (faylni topib bo'lmadi): qurilmada o'rnatilgan bo'lsa ishlaydi, aks holda Inter. Inter ilova ichida (`assets/fonts`).
- Android qismi **emulyator/qurilmada sinalmagan** (bu muhitda SDK yo'q); veb qismi Chrome da avtomatik sinalgan.
- Matnli PDF o'qiladi (pdf.js, oflayn, `web/assets/vendor/`); skanerlangan (rasm) PDF uchun OCR yo'q.
- Qoldiq taxminiy: faqat qayd etilgan to'lovlar hisobga olinadi, jarima/penya yo'q.
- Interfeys uz/ru/en tillarida to'liq tarjima qilingan (`assets/i18n.js`); qozoq/qirg'iz/tojik/turkman/tatar tillarida bo'limlar ruscha, fors/pushtu tillarida inglizcha ko'rsatiladi (faqat Sozlamalar o'sha tilda). Yangi matn qo'shsangiz, `i18n.js` lug'atiga ham qo'shing.
- Yangi logotiplar past aniqlikdagi manbadan kattalashtirilgan; asl yuqori sifatli fayllar bo'lsa, almashtiring.
- Sahifalar yagona routerda ro'yxatga olinadi: `registerPage(nom, fn)` (`index.html`); `.exe` yo'q.
