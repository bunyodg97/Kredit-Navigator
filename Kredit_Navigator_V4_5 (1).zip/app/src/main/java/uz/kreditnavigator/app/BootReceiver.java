package uz.kreditnavigator.app;
import android.content.*;import org.json.*;
public class BootReceiver extends BroadcastReceiver { @Override public void onReceive(Context c,Intent i){try{String json=c.getSharedPreferences("reminders",Context.MODE_PRIVATE).getString("data","[]");ReminderScheduler.schedule(c,new JSONArray(json));}catch(Exception e){android.util.Log.e("KreditNavigator","Reschedule failed",e);}} }
