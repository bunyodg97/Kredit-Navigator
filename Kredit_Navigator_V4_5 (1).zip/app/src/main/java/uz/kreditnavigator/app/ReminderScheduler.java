package uz.kreditnavigator.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;

public final class ReminderScheduler {
    static final String PREF = "alarm_ids";
    /** Android bitta ilova uchun ~500 ta alarm ruxsat beradi; xavfsiz chegara. */
    static final int MAX_ALARMS = 400;

    private static final class Trigger implements Comparable<Trigger> {
        long at; int code; String bank; long amount; int off;
        @Override public int compareTo(Trigger o) { return Long.compare(at, o.at); }
    }

    private ReminderScheduler() { }

    public static void schedule(Context c, JSONArray arr) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        SharedPreferences p = c.getSharedPreferences("reminders", Context.MODE_PRIVATE);

        // Eskilarini bekor qilish
        String old = p.getString(PREF, "");
        for (String id : old.split(",")) {
            try {
                int code = Integer.parseInt(id.trim());
                PendingIntent pi = PendingIntent.getBroadcast(c, code, new Intent(c, ReminderReceiver.class),
                        PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
                if (pi != null) am.cancel(pi);
            } catch (Exception ignored) { }
        }

        List<Trigger> all = new ArrayList<>();
        Calendar now = Calendar.getInstance();
        long limit = System.currentTimeMillis() + 2000;
        for (int i = 0; i < arr.length(); i++) {
            JSONObject x = arr.optJSONObject(i);
            if (x == null) continue;
            String uid = x.optString("id", String.valueOf(i));
            String bank = x.optString("bank", "Kredit");
            long amount = x.optLong("amount", 0);
            int day = Math.max(1, Math.min(31, x.optInt("day", 1)));
            int hour = 9, min = 0;
            try {
                String[] t = x.optString("time", "09:00").split(":");
                hour = Integer.parseInt(t[0]); min = Integer.parseInt(t[1]);
            } catch (Exception ignored) { }
            JSONArray offsets = x.optJSONArray("offsets");
            if (offsets == null) continue;
            for (int k = 0; k < offsets.length(); k++) {
                int off = offsets.optInt(k, 0);
                if (off < 0 || off > 30) continue;
                for (int month = 0; month < 24; month++) {
                    Calendar due = (Calendar) now.clone();
                    due.set(Calendar.DAY_OF_MONTH, 1);
                    due.add(Calendar.MONTH, month);
                    due.set(Calendar.DAY_OF_MONTH, Math.min(day, due.getActualMaximum(Calendar.DAY_OF_MONTH)));
                    due.set(Calendar.HOUR_OF_DAY, hour);
                    due.set(Calendar.MINUTE, min);
                    due.set(Calendar.SECOND, 0);
                    due.set(Calendar.MILLISECOND, 0);
                    Calendar at = (Calendar) due.clone();
                    at.add(Calendar.DAY_OF_MONTH, -off);
                    if (at.getTimeInMillis() <= limit) continue;
                    Trigger tr = new Trigger();
                    tr.at = at.getTimeInMillis();
                    tr.code = (uid + ":" + due.get(Calendar.YEAR) + ":" + due.get(Calendar.MONTH) + ":" + off).hashCode() & 0x7fffffff;
                    tr.bank = bank; tr.amount = amount; tr.off = off;
                    all.add(tr);
                }
            }
        }

        // Eng yaqin MAX_ALARMS tasini qoldiramiz (onResume/BootReceiver oynani yangilab turadi).
        Collections.sort(all);
        if (all.size() > MAX_ALARMS) all = all.subList(0, MAX_ALARMS);

        StringBuilder ids = new StringBuilder();
        for (Trigger tr : all) {
            Intent intent = new Intent(c, ReminderReceiver.class)
                    .putExtra("bank", tr.bank).putExtra("amount", tr.amount)
                    .putExtra("offset", tr.off).putExtra("code", tr.code);
            PendingIntent pi = PendingIntent.getBroadcast(c, tr.code, intent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            if (setAlarm(am, tr.at, pi)) ids.append(tr.code).append(',');
        }
        p.edit().putString(PREF, ids.toString()).apply();
    }

    private static boolean setAlarm(AlarmManager am, long at, PendingIntent pi) {
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            }
            return true;
        } catch (SecurityException first) {
            try {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
                return true;
            } catch (SecurityException second) {
                android.util.Log.w("KreditNavigator", "Alarm rad etildi", second);
                return false;
            }
        }
    }
}
