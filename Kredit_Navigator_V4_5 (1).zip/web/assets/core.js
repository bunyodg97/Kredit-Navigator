/* Kredit Navigator V4.5 — yagona yadro: ma'lumotlar, sana, hisob-kitob, CSV, zaxira.
   Boshqa modullar shu obyektdan foydalanadi (window.KNC). Node'da ham yuklanadi (testlar uchun). */
(function (root) {
  'use strict';
  const KEYS = { loans: 'kn-v21-loans', payments: 'kn-v21-payments', ledger: 'kn-v41-payment-ledger',
    reminders: 'kn_reminders_v34', ids: 'kn_payment_ids_v1', v3: 'kn-v3-data' };
  const ALL_KEYS = Object.keys(KEYS).map(k => KEYS[k]);
  const MIGRATED = 'kn-v45-migrated';

  const ls = () => { try { return root.localStorage; } catch (e) { return null; } };
  function read(k, fb) { try { const v = JSON.parse(ls().getItem(k)); return v == null ? fb : v; } catch (e) { return fb; } }
  function write(k, v) { ls().setItem(k, JSON.stringify(v)); }
  const N = x => Math.max(0, Number(x) || 0);
  const pad = n => String(n).padStart(2, '0');
  const iso = d => d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
  function parseISO(s) {
    const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(s || '')); if (!m) return null;
    const d = new Date(+m[1], +m[2] - 1, +m[3], 12);
    return (isNaN(d) || d.getMonth() !== +m[2] - 1) ? null : d;
  }
  /** DD.MM.YYYY, DD/MM/YYYY, DD-MM-YYYY yoki YYYY-MM-DD -> 'YYYY-MM-DD' yoki null */
  function parseDate(s) {
    s = String(s == null ? '' : s).trim();
    if (parseISO(s)) return s;
    const m = /^(\d{1,2})[./-](\d{1,2})[./-](\d{4})$/.exec(s); if (!m) return null;
    const out = m[3] + '-' + pad(+m[2]) + '-' + pad(+m[1]); return parseISO(out) ? out : null;
  }
  /** Oy oxiri bo'yicha qisqartiriladi (31-sana -> fevralda 28/29). */
  function addMonths(y, m, day, k) {
    const t = m + k, yy = y + Math.floor(t / 12), mm = ((t % 12) + 12) % 12;
    return new Date(yy, mm, Math.min(day, new Date(yy, mm + 1, 0).getDate()), 12);
  }

  /* ---------- Kredit modeli ---------- */
  function normalizeLoan(l, i) {
    l = l || {};
    const out = Object.assign({}, l);
    out.id = (l.id === undefined || l.id === null || l.id === '') ? 'k' + Date.now() + '-' + (i || 0) : String(l.id);
    out.name = String(l.name == null ? '' : l.name);
    ['principal', 'annual', 'months', 'insurance', 'extra'].forEach(f => { out[f] = N(l[f]); });
    out.method = l.method === 'diff' ? 'diff' : 'annuity';
    out.insuranceMode = l.insuranceMode === 'separate' ? 'separate' : 'financed';
    if (l.day != null && l.day !== '') out.day = Math.min(31, Math.max(1, Math.round(+l.day) || 1)); else delete out.day;
    return out;
  }
  function loans() { const a = read(KEYS.loans, []); return (Array.isArray(a) ? a : []).filter(x => x && typeof x === 'object').map(normalizeLoan); }
  function saveLoans(a) { write(KEYS.loans, a); }
  function ledger() { const a = read(KEYS.ledger, []); return Array.isArray(a) ? a : []; }
  function saveLedger(a) { write(KEYS.ledger, a); }
  function notify() { try { root.dispatchEvent(new root.Event('kn:loans-changed')); } catch (e) { } }

  function startFromFirst(firstISO) {
    const f = parseISO(firstISO); if (!f) return null;
    return iso(addMonths(f.getFullYear(), f.getMonth(), f.getDate(), -1));
  }
  function firstPay(l) {
    if (!l) return null;
    const f = parseISO(l.firstPay); if (f) return f;
    const s = parseISO(l.start); if (!s) return null;
    return addMonths(s.getFullYear(), s.getMonth(), Math.min(31, Math.max(1, Math.round(+l.day) || s.getDate())), 1);
  }
  /** i-to'lov sanasi (i >= 1) yoki null */
  function dueDate(l, i) {
    const f = firstPay(l); if (!f) return null;
    const day = Math.min(31, Math.max(1, Math.round(+(l.day || f.getDate())) || f.getDate()));
    return addMonths(f.getFullYear(), f.getMonth(), day, i - 1);
  }
  function annuity(p, annual, n) { const r = annual / 1200; return n ? (r ? p * r / (1 - Math.pow(1 + r, -n)) : p / n) : 0; }
  const months = l => Math.max(1, Math.min(600, Math.round(N(l.months)) || 1));
  /** i-oy uchun rejadagi to'lov (annuitet yoki differensial) */
  function expectedPayment(l, i) {
    const p = N(l.principal), n = months(l), r = N(l.annual) / 1200;
    return l.method === 'diff' ? p / n + p * (1 - ((i || 1) - 1) / n) * r : annuity(p, N(l.annual), n);
  }
  /** Reja jadvali: [{i,payment,interest,principal,balance}] (qo'shimcha to'lovsiz) */
  function plan(l) {
    const n = months(l), r = N(l.annual) / 1200; let b = N(l.principal); const rows = [];
    for (let i = 1; i <= n && b > 0.001; i++) {
      const f = b * r, pay = Math.min(b + f, expectedPayment(l, i)), pr = pay - f;
      b = Math.max(0, b - pr); rows.push({ i, payment: pay, interest: f, principal: pr, balance: b });
    }
    return rows;
  }
  /** Qayd etilgan to'lovlar asosida taxminiy qoldiq. Faqat to'lov qayd etilgan oylar hisobga olinadi. */
  function balance(l, led) {
    const r = N(l.annual) / 1200, paid = {}; let paidTotal = 0;
    (led || []).forEach(e => { if (String(e.loanId) === String(l.id)) { paid[e.month] = (paid[e.month] || 0) + N(e.amount); paidTotal += N(e.amount); } });
    let b = N(l.principal);
    Object.keys(paid).map(Number).sort((a, c) => a - c).forEach(m => { b += b * r; b = Math.max(0, b - paid[m]); });
    return { balance: b, paidTotal, monthsPaid: Object.keys(paid).length };
  }
  function nextDue(list, today) {
    today = today || new Date(); const t0 = new Date(today.getFullYear(), today.getMonth(), today.getDate(), 0);
    let best = null;
    list.forEach(l => { for (let i = 1; i <= months(l); i++) { const d = dueDate(l, i); if (d && d >= t0) { if (!best || d < best.date) best = { date: d, loan: l, month: i }; break; } } });
    return best;
  }
  function dueDaysInMonth(list, y, m) {
    const days = new Set();
    list.forEach(l => { for (let i = 1; i <= months(l); i++) { const d = dueDate(l, i); if (d && d.getFullYear() === y && d.getMonth() === m) days.add(d.getDate()); } });
    return days;
  }
  /** Sanaga eng yaqin to'lov oyi (1..n) */
  function matchMonth(l, dateISO) {
    const d = parseISO(dateISO); if (!d) return null; let best = null, bd = Infinity;
    for (let i = 1; i <= months(l); i++) { const due = dueDate(l, i); if (!due) return null; const diff = Math.abs(due - d); if (diff < bd) { bd = diff; best = i; } }
    return best;
  }
  function removeLoan(id) {
    saveLoans(loans().filter(x => String(x.id) !== String(id)));
    saveLedger(ledger().filter(x => String(x.loanId) !== String(id)));
    notify();
  }

  /* ---------- Son va CSV ---------- */
  function parseAmount(s) {
    if (typeof s === 'number') return isFinite(s) ? s : NaN;
    let t = String(s == null ? '' : s).replace(/[\s ]/g, '').replace(/[^\d.,-]/g, ''); if (!t) return NaN;
    const neg = t[0] === '-'; t = t.replace(/-/g, '');
    const dots = (t.match(/\./g) || []).length, commas = (t.match(/,/g) || []).length; let out;
    if (dots && commas) { const dec = t.lastIndexOf('.') > t.lastIndexOf(',') ? '.' : ','; const th = dec === '.' ? ',' : '.'; out = t.split(th).join('').replace(dec, '.'); }
    else if (dots || commas) {
      const sep = dots ? '.' : ',', parts = t.split(sep);
      if (parts.length > 2) out = parts.join('');
      else out = (/^\d{3}$/.test(parts[1]) && parts[0].length <= 3 && parts[0] !== '0' && parts[0] !== '') ? parts.join('') : parts[0] + '.' + parts[1];
    } else out = t;
    const v = Number(out); return isFinite(v) ? (neg ? -v : v) : NaN;
  }
  function detectDelimiter(text) {
    const line = String(text).replace(/^﻿/, '').split(/\r?\n/).find(x => x.trim()) || '';
    const c = { ';': (line.match(/;/g) || []).length, ',': (line.match(/,/g) || []).length, '\t': (line.match(/\t/g) || []).length };
    return c[';'] >= c[','] && c[';'] >= c['\t'] && c[';'] > 0 ? ';' : (c['\t'] > c[','] ? '\t' : ',');
  }
  function parseCSV(t, delim) {
    t = String(t).replace(/^﻿/, ''); delim = delim || detectDelimiter(t);
    const rows = []; let row = [], cell = '', q = false;
    for (let i = 0; i < t.length; i++) {
      const c = t[i];
      if (c === '"') { if (q && t[i + 1] === '"') { cell += '"'; i++; } else q = !q; }
      else if (c === delim && !q) { row.push(cell); cell = ''; }
      else if ((c === '\n' || c === '\r') && !q) { if (c === '\r' && t[i + 1] === '\n') i++; row.push(cell); if (row.some(x => x.trim())) rows.push(row); row = []; cell = ''; }
      else cell += c;
    }
    row.push(cell); if (row.some(x => x.trim())) rows.push(row); return rows;
  }

  /* ---------- Fayl: rasm kichraytirish ---------- */
  function fileToDataURL(file, opt) {
    opt = opt || {};
    return new Promise((ok, fail) => {
      const rd = new FileReader();
      rd.onerror = () => fail(new Error('Faylni o‘qib bo‘lmadi'));
      rd.onload = () => {
        if (!/^image\/(png|jpeg)$/.test(file.type)) return ok(rd.result);
        const img = new Image();
        img.onerror = () => ok(rd.result);
        img.onload = () => {
          const max = opt.maxPx || 1400, k = Math.min(1, max / Math.max(img.width, img.height));
          const c = document.createElement('canvas'); c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
          c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
          ok(c.toDataURL('image/jpeg', opt.quality || 0.72));
        };
        img.src = rd.result;
      };
      rd.readAsDataURL(file);
    });
  }

  /* ---------- Shifrlash (AES-GCM + PBKDF2) ---------- */
  function toB64(bytes) { let s = ''; for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000)); return btoa(s); }
  function fromB64(s) { const b = atob(s), a = new Uint8Array(b.length); for (let i = 0; i < b.length; i++) a[i] = b.charCodeAt(i); return a; }
  const ITER = 250000, MIN_PASS = 10;
  async function key(pass, salt, usage) {
    const base = await crypto.subtle.importKey('raw', new TextEncoder().encode(pass), 'PBKDF2', false, ['deriveKey']);
    return crypto.subtle.deriveKey({ name: 'PBKDF2', salt, iterations: ITER, hash: 'SHA-256' }, base, { name: 'AES-GCM', length: 256 }, false, usage);
  }
  async function seal(pass, obj) {
    const salt = crypto.getRandomValues(new Uint8Array(16)), iv = crypto.getRandomValues(new Uint8Array(12)), k = await key(pass, salt, ['encrypt']);
    const ct = new Uint8Array(await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, k, new TextEncoder().encode(JSON.stringify(obj))));
    return { format: 'KN-V4.5-AES-GCM', salt: toB64(salt), iv: toB64(iv), cipher: toB64(ct) };
  }
  async function unseal(pass, o) {
    const k = await key(pass, fromB64(o.salt), ['decrypt']);
    return JSON.parse(new TextDecoder().decode(await crypto.subtle.decrypt({ name: 'AES-GCM', iv: fromB64(o.iv) }, k, fromB64(o.cipher))));
  }
  const isEncrypted = o => o && /^KN-(V3-|V4\.5-)?AES-GCM$/.test(o.format || '');

  /* ---------- To'liq zaxira ---------- */
  function exportAll() {
    const store = {}; ALL_KEYS.forEach(k => { const v = ls().getItem(k); if (v != null) store[k] = v; });
    return { format: 'KN-V4.5', exported: new Date().toISOString(), store };
  }
  /** Eski (V2.1/V3) va yangi formatlarni qabul qiladi; shaklni tekshiradi. */
  function importAll(obj) {
    if (!obj || typeof obj !== 'object') throw new Error('format');
    if (obj.store && typeof obj.store === 'object') {
      const next = {};
      ALL_KEYS.forEach(k => { if (typeof obj.store[k] === 'string') { JSON.parse(obj.store[k]); next[k] = obj.store[k]; } });
      if (next[KEYS.loans]) { const a = JSON.parse(next[KEYS.loans]); if (!Array.isArray(a)) throw new Error('loans'); next[KEYS.loans] = JSON.stringify(a.map(normalizeLoan)); }
      ALL_KEYS.forEach(k => ls().removeItem(k)); Object.keys(next).forEach(k => ls().setItem(k, next[k]));
    } else {
      const src = obj.v3 ? obj : obj; if (!Array.isArray(src.loans)) throw new Error('loans');
      saveLoans(src.loans.map(normalizeLoan));
      write(KEYS.payments, Array.isArray(src.payments) ? src.payments : []);
      if (obj.v3 && typeof obj.v3 === 'object') write(KEYS.v3, obj.v3);
    }
    ls().removeItem(MIGRATED); migrate(); notify();
  }
  function clearAll() { ALL_KEYS.forEach(k => ls().removeItem(k)); ls().removeItem(MIGRATED); notify(); }

  /* ---------- Migratsiya (bir martalik) ---------- */
  function migrate() {
    const st = ls(); if (!st) return;
    try {
      // 1) ID larni satrga keltirish (son ID lar tahrirlash/daftar bilan mos kelmas edi)
      const raw = read(KEYS.loans, null);
      if (Array.isArray(raw) && raw.some(x => x && typeof x.id !== 'string')) {
        const map = {}; raw.forEach((x, i) => { if (x && typeof x.id !== 'string') map[String(x.id)] = true; });
        saveLoans(raw.filter(x => x && typeof x === 'object').map(normalizeLoan));
      }
      const led = read(KEYS.ledger, null);
      if (Array.isArray(led) && led.some(e => e && typeof e.loanId !== 'string')) saveLedger(led.map(e => Object.assign({}, e, { loanId: String(e.loanId) })));
      // 2) Eski V3 "cheklar" ni yagona daftarga ko'chirish
      if (!st.getItem(MIGRATED)) {
        const v3 = read(KEYS.v3, null), ls0 = loans();
        if (v3 && Array.isArray(v3.receipts) && v3.receipts.length && ls0.length) {
          const led2 = ledger();
          v3.receipts.forEach(r => {
            const lo = ls0.find(l => String(l.bank || l.name || '').toLowerCase() === String(r.bank || '').toLowerCase()) || ls0[0];
            const d = parseDate(r.date); const m = d ? (matchMonth(lo, d) || 1) : 1;
            led2.push({ id: 'p' + Date.now() + Math.random().toString(36).slice(2, 7), loanId: lo.id, month: m, amount: N(r.amount), date: d || iso(new Date()), method: 'Boshqa', note: r.note || '', receipt: r.attachment || '', filename: '' });
          });
          saveLedger(led2); v3.receipts = []; write(KEYS.v3, v3);
        }
        if (!v3 || !v3.receipts || !v3.receipts.length) st.setItem(MIGRATED, '1');
      }
    } catch (e) { try { console.warn('migrate', e); } catch (x) { } }
  }

  const fmt = n => Math.round(Number(n) || 0).toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.');
  const money = n => fmt(n) + ' so‘m';

  const KNC = { KEYS, ALL_KEYS, MIN_PASS, N, iso, parseISO, parseDate, addMonths, normalizeLoan, loans, saveLoans, ledger, saveLedger,
    startFromFirst, firstPay, dueDate, annuity, expectedPayment, plan, balance, nextDue, dueDaysInMonth, matchMonth, removeLoan,
    parseAmount, detectDelimiter, parseCSV, fileToDataURL, toB64, fromB64, seal, unseal, isEncrypted, exportAll, importAll, clearAll,
    migrate, notify, fmt, money, months };
  root.KNC = KNC;
  if (typeof module !== 'undefined' && module.exports) module.exports = KNC;
  if (ls()) migrate();
})(typeof window !== 'undefined' ? window : globalThis);
