/* Android WebView: Blob/data: yuklab olishlar (a[download]) ni native saveFile ko'prigiga yo'naltiradi. */
(function () {
  'use strict';
  if (!window.KreditAndroid || !window.KreditAndroid.saveFile) return;
  const blobs = new Map(), create = URL.createObjectURL.bind(URL);
  URL.createObjectURL = function (b) { const u = create(b); if (b instanceof Blob) { blobs.set(u, b); setTimeout(() => blobs.delete(u), 120000); } return u; };
  const toB64 = blob => new Promise((ok, fail) => { const r = new FileReader(); r.onload = () => { const s = String(r.result); ok(s.slice(s.indexOf(',') + 1)); }; r.onerror = fail; r.readAsDataURL(blob); });
  const click = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function () {
    const a = this, href = a.href || '';
    if (a.hasAttribute('download') && /^(blob:|data:)/.test(href)) {
      const name = a.download || 'fayl';
      const fail = () => alert('Faylni saqlab bo‘lmadi');
      if (href.startsWith('data:')) {
        const m = /^data:([^;,]*)(;base64)?,(.*)$/s.exec(href);
        if (!m) return fail();
        const data = m[2] ? m[3] : btoa(unescape(decodeURIComponent(m[3])));
        try { window.KreditAndroid.saveFile(name, m[1] || 'application/octet-stream', data); } catch (e) { fail(); }
        return;
      }
      const blob = blobs.get(href); if (!blob) return fail();
      toB64(blob).then(d => window.KreditAndroid.saveFile(name, blob.type || 'application/octet-stream', d)).catch(fail);
      return;
    }
    return click.apply(this, arguments);
  };
})();
