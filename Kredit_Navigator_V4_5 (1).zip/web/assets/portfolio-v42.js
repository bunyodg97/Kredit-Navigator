/* Dashboard: haqiqiy qoldiq (qayd etilgan to'lovlar asosida), grafik, taqvim, tavsiya (V4.5) */
(()=>{'use strict';
const $=id=>document.getElementById(id);
const safe=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const COLORS=['#13c8ff','#a768f9','#30e4ac','#f1b24b'];
const MONTHS=['yanvar','fevral','mart','aprel','may','iyun','iyul','avgust','sentabr','oktabr','noyabr','dekabr'];
const money=KNC.money;
function niceMax(v){if(v<=0)return 1;const p=Math.pow(10,Math.floor(Math.log10(v))),f=v/p;return(f<=1?1:f<=2?2:f<=2.5?2.5:f<=5?5:10)*p}
function short(v){return v>=1e9?(v/1e9).toFixed(1).replace(/\.0$/,'')+' mlrd':v>=1e6?(v/1e6).toFixed(v>=1e7?0:1).replace(/\.0$/,'')+' mln':v>=1e3?Math.round(v/1e3)+' ming':'0'}
function render(){
 const loans=KNC.loans().filter(l=>l.principal>0),led=KNC.ledger();
 let debt=0,monthly=0,interest=0,total=0,insurance=0,maxM=0,principal=0;
 const items=loans.map(l=>{const rows=KNC.plan(l),b=KNC.balance(l,led),intr=rows.reduce((s,r)=>s+r.interest,0);
  debt+=b.balance;monthly+=KNC.expectedPayment(l,1);interest+=intr;insurance+=l.insurance;principal+=l.principal;
  total+=l.principal+intr+(l.insuranceMode==='separate'?l.insurance:0);maxM=Math.max(maxM,KNC.months(l));return{l,rows,bal:b.balance}});
 const vals={debt,monthly,interest,insure:insurance,total};Object.keys(vals).forEach(id=>{const el=$(id);if(el)el.textContent=money(vals[id])});
 const dv=$('donutval');if(dv)dv.textContent=(debt/1e6).toFixed(2).replace('.',',')+' mln';
 // bank bo'yicha taqsimot
 const groups=new Map();items.forEach(({l,bal})=>{const n=l.bank||l.name||'Boshqa bank',g=groups.get(n)||{amount:0,count:0};g.amount+=bal;g.count++;groups.set(n,g)});
 const legend=document.querySelector('.legend');
 if(legend)legend.innerHTML=groups.size?[...groups].map(([n,g],i)=>`<div><i style="background:${COLORS[i%4]}"></i>${safe(n)} (${g.count} ta)<p style="margin:6px 0 0 25px">${debt?Math.round(g.amount/debt*100):0}%　${money(g.amount)}</p></div>`).join(''):'<div class="muted">Hozircha kredit qo‘shilmagan.</div>';
 const donut=document.querySelector('.donut');
 if(donut){if(debt>0){let a=0;donut.style.background='conic-gradient('+[...groups].map(([n,g],i)=>{const s=a;a+=g.amount/debt*100;return`${COLORS[i%4]} ${s}% ${a}%`}).join(',')+')'}else donut.style.background='conic-gradient(#17466c 0% 100%)'}
 // keyingi to'lov va belgi
 const nd=KNC.nextDue(loans),next=$('nextdue');
 if(next)next.textContent=nd?`Keyingi to‘lov: ${nd.date.getDate()}-${MONTHS[nd.date.getMonth()]}, ${nd.date.getFullYear()} — ${nd.loan.bank||nd.loan.name} (${money(KNC.expectedPayment(nd.loan,nd.month))})`:(loans.length?'Keyingi to‘lov sanasi topilmadi':'Keyingi to‘lov: —');
 const soon=loans.filter(l=>{const x=KNC.nextDue([l]);if(!x)return false;const days=(x.date-new Date())/864e5;if(days>7)return false;const paid=led.filter(e=>String(e.loanId)===String(l.id)&&e.month===x.month).reduce((s,e)=>s+Number(e.amount||0),0);return paid<KNC.expectedPayment(l,x.month)-.5}).length;
 const dc=$('dueCount');if(dc)dc.textContent=soon?String(soon):'';
 // tavsiya
 const at=$('adviceTitle'),ax=$('adviceText');
 if(at&&ax){if(!loans.length){at.textContent='Birinchi kreditingizni qo‘shing';ax.textContent='Kredit qo‘shilgach, bu yerda foiz va yopish bo‘yicha tavsiya chiqadi.'}else{const top=loans.slice().sort((a,b)=>b.annual-a.annual)[0];at.textContent=`Eng qimmat kredit: ${top.name||top.bank} (${top.annual}%)`;ax.textContent='Qo‘shimcha to‘lovni shu kreditga yo‘naltirish foiz xarajatini eng ko‘p kamaytiradi. Rejani “Tahlil va Maslahat” bo‘limida hisoblang.'}}
 // grafik
 const debtL=$('debtLine'),payL=$('payLine');if(!debtL||!payL)return;
 const M=Math.max(1,maxM),planned=[],cum=[];let lastPaid=0;
 for(let i=0;i<=M;i++){let r=0;items.forEach(({l,rows})=>{r+=i===0?l.principal:(rows[Math.min(i,rows.length)-1]?.balance??0)});planned.push(r)}
 const ids=new Set(loans.map(l=>String(l.id))),mine=led.filter(e=>ids.has(String(e.loanId)));
 mine.forEach(e=>{lastPaid=Math.max(lastPaid,Math.min(M,Number(e.month)||0))});
 for(let i=0;i<=lastPaid;i++)cum.push(mine.filter(e=>(Number(e.month)||0)<=i).reduce((s,e)=>s+Number(e.amount||0),0));
 const yMax=niceMax(Math.max(principal,...planned,...(cum.length?cum:[0]))),X=i=>55+610*i/M,Y=v=>175-160*v/yMax;
 const path=pts=>pts.map(([x,y],i)=>(i?'L':'M')+x.toFixed(1)+' '+y.toFixed(1)).join(' ');
 const pd=planned.map((v,i)=>[X(i),Y(v)]),pp=cum.map((v,i)=>[X(i),Y(v)]);
 debtL.setAttribute('d',loans.length?path(pd):'');payL.setAttribute('d',pp.length>1?path(pp):'');
 $('debtArea')?.setAttribute('d',loans.length?path(pd)+' L'+X(M).toFixed(1)+' 175 L55 175 Z':'');
 $('payArea')?.setAttribute('d',pp.length>1?path(pp)+' L'+X(lastPaid).toFixed(1)+' 175 L55 175 Z':'');
 const ax2=$('axisLabels');
 if(ax2){let h='';for(let j=0;j<=4;j++)h+=`<text x="50" y="${15+40*j+4}" text-anchor="end">${j===4?'0':short(yMax*(4-j)/4)}</text>`;for(let k=0;k<=5;k++)h+=`<text x="${55+610*k/5}" y="198" text-anchor="middle">${Math.round(M*k/5)} oy</text>`;ax2.innerHTML=h}
 const chart=document.querySelector('.chartwrap');
 if(chart){chart.querySelector('.kn-chart-note')?.remove();if(!loans.length){const n=document.createElement('div');n.className='kn-chart-note';n.textContent='Grafik kredit qo‘shilgandan keyin shakllanadi.';n.style.cssText='text-align:center;color:#b9d5f7;margin-top:-90px;position:relative';chart.appendChild(n)}}
 window.drawCal?.();
}
window.KNPortfolio={render};
window.addEventListener('kn:loans-changed',render);
window.addEventListener('storage',e=>{if(e.key&&KNC.ALL_KEYS.includes(e.key))render()});
document.addEventListener('click',e=>{if(e.target.closest('[data-page="dashboard"],.panelhead button'))setTimeout(render,0)});
render();
})();
