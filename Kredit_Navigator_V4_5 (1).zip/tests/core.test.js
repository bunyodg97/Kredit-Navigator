// Ishga tushirish: node --test
const test = require('node:test');
const assert = require('node:assert/strict');
const mem = {}; globalThis.localStorage = { getItem: k => (k in mem ? mem[k] : null), setItem: (k, v) => { mem[k] = String(v); }, removeItem: k => { delete mem[k]; } };
const KNC = require('../web/assets/core.js');
const reset = () => Object.keys(mem).forEach(k => delete mem[k]);

test('annuity va reja jadvali qarzni 0 ga tushiradi', () => {
  const l = { principal: 12000000, annual: 24, months: 12 };
  const rows = KNC.plan(l);
  assert.equal(rows.length, 12);
  assert.ok(rows[11].balance < 0.01);
  assert.ok(Math.abs(KNC.expectedPayment(l, 1) - 1134715) < 1);
});
test('differensial: birinchi to\'lov kattaroq va kamayib boradi', () => {
  const l = { principal: 6000000, annual: 30, months: 6, method: 'diff' };
  assert.ok(KNC.expectedPayment(l, 1) > KNC.expectedPayment(l, 6));
  assert.ok(KNC.plan(l).at(-1).balance < 0.01);
});
test('to\'lov sanasi: oy oxirida qisqartiriladi (31 -> 28/29)', () => {
  const l = { firstPay: '2027-01-31', months: 4 };
  assert.deepEqual([1, 2, 3, 4].map(i => KNC.iso(KNC.dueDate(l, i))), ['2027-01-31', '2027-02-28', '2027-03-31', '2027-04-30']);
});
test('start/day dan birinchi to\'lov hisoblanadi; bo\'sh bo\'lsa null', () => {
  assert.equal(KNC.iso(KNC.firstPay({ start: '2026-11-20', day: 18 })), '2026-12-18');
  assert.equal(KNC.dueDate({ start: '', months: 3 }, 1), null);
  assert.equal(KNC.startFromFirst('2026-12-18'), '2026-11-18');
});
test('parseAmount turli formatlarni tushunadi', () => {
  const c = [['904831', 904831], ['904.831', 904831], ['904,831', 904831], ['1 000 000,50', 1000000.5], ['6.000.000', 6000000], ['12,5', 12.5], ['0.5', 0.5], ['1,234.56', 1234.56], ['1.234,56', 1234.56]];
  c.forEach(([s, v]) => assert.equal(KNC.parseAmount(s), v, s));
  assert.ok(Number.isNaN(KNC.parseAmount('abc')));
});
test('parseDate: ISO va DD.MM.YYYY, noto\'g\'ri sana rad etiladi', () => {
  assert.equal(KNC.parseDate('18.12.2026'), '2026-12-18');
  assert.equal(KNC.parseDate('2026-12-18'), '2026-12-18');
  assert.equal(KNC.parseDate('31.02.2026'), null);
  assert.equal(KNC.parseDate('bad'), null);
});
test('CSV: ajratgich avtomatik aniqlanadi', () => {
  assert.equal(KNC.detectDelimiter('date;amount;bank'), ';');
  assert.equal(KNC.detectDelimiter('date,amount,bank'), ',');
  assert.deepEqual(KNC.parseCSV('a;b\n"x;y";2\n'), [['a', 'b'], ['x;y', '2']]);
});
test('ID lar satrga keltiriladi (migratsiya) va kredit o\'chirilganda daftar ham tozalanadi', () => {
  reset();
  localStorage.setItem(KNC.KEYS.loans, JSON.stringify([{ id: 1700000000000, principal: 1000, annual: 10, months: 3 }]));
  localStorage.setItem(KNC.KEYS.ledger, JSON.stringify([{ id: 'p1', loanId: 1700000000000, month: 1, amount: 100 }]));
  KNC.migrate();
  assert.equal(typeof KNC.loans()[0].id, 'string');
  assert.equal(KNC.ledger()[0].loanId, '1700000000000');
  KNC.removeLoan('1700000000000');
  assert.equal(KNC.loans().length, 0);
  assert.equal(KNC.ledger().length, 0);
});
test('qoldiq faqat qayd etilgan to\'lovlar asosida kamayadi', () => {
  const l = { id: 'a', principal: 1000000, annual: 24, months: 12 };
  assert.equal(KNC.balance(l, []).balance, 1000000);
  const b = KNC.balance(l, [{ loanId: 'a', month: 1, amount: 100000 }]);
  assert.ok(Math.abs(b.balance - (1000000 * 1.02 - 100000)) < 0.01);
  assert.equal(b.paidTotal, 100000);
});
test('matchMonth: sanaga eng yaqin to\'lov oyi', () => {
  const l = { firstPay: '2026-12-18', months: 6 };
  assert.equal(KNC.matchMonth(l, '2027-01-17'), 2);
  assert.equal(KNC.matchMonth(l, '2026-12-01'), 1);
});
test('base64 katta ma\'lumotda qulamaydi', () => {
  const big = new Uint8Array(3000000).map((_, i) => i % 251);
  assert.deepEqual(KNC.fromB64(KNC.toB64(big)), big);
});
test('shifrlash: aylanma yo\'l va noto\'g\'ri parol', async () => {
  const sealed = await KNC.seal('correct-horse-battery', { a: 1, s: 'x'.repeat(300000) });
  assert.equal(KNC.isEncrypted(sealed), true);
  assert.equal((await KNC.unseal('correct-horse-battery', sealed)).a, 1);
  await assert.rejects(KNC.unseal('wrong-password-xx', sealed));
});
test('importAll: eski va yangi formatlar, yaroqsizi rad etiladi', () => {
  reset();
  KNC.importAll({ loans: [{ id: 5, principal: 10, annual: 1, months: 1 }], payments: [] });
  assert.equal(KNC.loans()[0].id, '5');
  assert.throws(() => KNC.importAll({ foo: 1 }));
  const snap = KNC.exportAll(); reset(); KNC.importAll(snap);
  assert.equal(KNC.loans().length, 1);
});
