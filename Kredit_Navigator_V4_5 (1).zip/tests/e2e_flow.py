import asyncio, json, os, base64
from playwright.async_api import async_playwright
URL='file://'+__import__('os').path.abspath(__import__('os').path.join(__import__('os').path.dirname(__file__),'..','web','index.html'))+''
res=[]
async def nav(pg,name):
    await pg.evaluate('(n)=>document.querySelector(\'#nav button[data-page="\'+n+\'"]\').click()',name)
def ok(name,cond,extra=''):
    res.append((name,bool(cond))); print(('PASS ' if cond else 'FAIL ')+name+(' | '+str(extra) if extra else ''))
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(headless=True,args=['--no-sandbox'])
        ctx=await b.new_context(viewport={'width':1400,'height':1000},accept_downloads=True,timezone_id='Asia/Tashkent')
        pg=await ctx.new_page(); errs=[]
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.on('console',lambda m:errs.append('CONSOLE '+m.text) if m.type=='error' else None)
        dialogs=[]
        async def on_dialog(d): dialogs.append(d.message); await d.accept()
        pg.on('dialog',lambda d:asyncio.ensure_future(on_dialog(d)))
        await pg.goto(URL); await pg.wait_for_timeout(300)
        # --- 1. Loan 1 via bank picker
        await nav(pg,'loans'); await pg.wait_for_timeout(300)
        await pg.click('.banktile:has-text("Agrobank")')
        await pg.fill('#bn','Avtokredit'); await pg.fill('#bp','12000000'); await pg.fill('#br','24'); await pg.fill('#bm','12')
        await pg.fill('#bi','500000'); await pg.fill('#bd','2026-12-18')
        await pg.click('#savebank'); await pg.wait_for_timeout(300)
        loans=await pg.evaluate('KNC.loans()')
        ok('loan saved with string id/day/firstPay',len(loans)==1 and isinstance(loans[0]['id'],str) and loans[0]['day']==18 and loans[0]['firstPay']=='2026-12-18',loans[0] if loans else None)
        # --- 2. Loan 2 (diff + separate insurance) via tile without logo
        await pg.click('.banktile:has-text("Xalq banki")')
        await pg.fill('#bp','6000000'); await pg.fill('#br','30'); await pg.fill('#bm','6'); await pg.fill('#bi','300000')
        await pg.select_option('#bim','separate'); await pg.select_option('#bmeth','diff'); await pg.fill('#bd','2027-01-31')
        await pg.click('#savebank'); await pg.wait_for_timeout(300)
        ok('2 loans listed',await pg.locator('#savedbanks .bankrow').count()==2)
        # day 31 clamp
        d=await pg.evaluate("[KNC.iso(KNC.dueDate(KNC.loans()[1],1)),KNC.iso(KNC.dueDate(KNC.loans()[1],2))]")
        ok('31st clamps to Feb 28',d==['2027-01-31','2027-02-28'],d)
        # --- 3. dashboard
        await nav(pg,'dashboard'); await pg.wait_for_timeout(300)
        debt=await pg.inner_text('#debt'); total=await pg.inner_text('#total')
        ok('dashboard debt = 18.000.000',debt.startswith('18.000.000'),debt)
        await pg.screenshot(path='s2_dashboard.png')
        # separate insurance included in total: principal+interest+300000
        t=await pg.evaluate("(()=>{const ls=KNC.loans();return ls.reduce((a,l)=>a+KNC.plan(l).reduce((s,r)=>s+r.payment,0)+(l.insuranceMode==='separate'?l.insurance:0),0)})()")
        ok('total includes separate insurance',KNC.fmt if False else abs(int(total.split(' ')[0].replace('.',''))-round(t))<=1,(total,round(t)))
        axis=await pg.evaluate("document.getElementById('axisLabels').textContent")
        ok('axis labels dynamic (12 oy)','12 oy' in axis,axis[:80])
        nd=await pg.inner_text('#nextdue'); ok('nextdue dynamic',('2026' in nd or '2027' in nd) and 'dekabr' in nd,nd)
        # calendar month navigation: due day marked in Dec 2026
        for _ in range(12):
            if 'Dekabr 2026' in await pg.inner_text('#calmonth'): break
            await pg.click('.calhead button:last-child')
        ok('calendar marks due day 18 in Dec 2026',await pg.locator('#cal .due').inner_text()=='18')
        # --- 4. ledger: record payment for loan1 month 1
        await nav(pg,'payment-ledger'); await pg.wait_for_timeout(300)
        ok('ledger shows both loans in select',await pg.locator('#v41loan option').count()==2)
        await pg.screenshot(path='s3_ledger.png')
        await pg.fill('#v41amount','2000000')
        await pg.click('#v41form button[type=submit]'); await pg.wait_for_timeout(300)
        led=await pg.evaluate('KNC.ledger()')
        ok('payment recorded with string loanId',len(led)==1 and led[0]['loanId']==loans[0]['id'] and led[0]['month']==1,led)
        stat=await pg.inner_text('.v41stats')
        ok('status updated',('Qisman' in stat) or ('To‘landi' in stat),stat.replace('\n',' | ')[:120])
        await nav(pg,'dashboard'); await pg.wait_for_timeout(300)
        debt2=await pg.inner_text('#debt')
        ok('debt decreased after payment',int(debt2.split(' ')[0].replace('.',''))<18000000,debt2)
        # --- 5. CSV import semicolon + dd.mm.yyyy + dot-thousands
        csv='date;amount;bank;note\n18.12.2026;904.831;Agrobank;oy 1\n2027-01-18;"1 000 000,50";Agrobank;oy 2\nbad;x;;\n'
        open('/tmp/imp.csv','w').write(csv)
        await nav(pg,'imports'); await pg.wait_for_timeout(300)
        await pg.set_input_files('#if','/tmp/imp.csv'); await pg.click('button:has-text("CSVni tekshirish")'); await pg.wait_for_timeout(300)
        txt=await pg.inner_text('#vresult'); ok('CSV ; accepted, 1 bad skipped',('2 ta yangi' in txt) and ('1 tasi' in txt),txt[:120])
        await pg.click('button:has-text("Tasdiqlash va import")'); await pg.wait_for_timeout(300)
        led=await pg.evaluate('KNC.ledger()'); ok('imported into ledger',len(led)==3,[ (e['month'],e['amount']) for e in led])
        await pg.set_input_files('#if','/tmp/imp.csv'); await pg.click('button:has-text("CSVni tekshirish")'); await pg.wait_for_timeout(300)
        txt=await pg.inner_text('#vresult'); ok('re-import deduped',('0 ta yangi' in txt) and ('allaqachon' in txt),txt[:100])
        # --- 6. calendar ics download
        await nav(pg,'calendar'); await pg.wait_for_timeout(300)
        async with pg.expect_download() as dl: await pg.click('button:has-text("Barcha kreditlar (.ics)")')
        f=await dl.value; path=await f.path(); ics=open(path).read()
        ok('ICS valid (no NaN, DTSTAMP, 18 events)',('NaN' not in ics) and 'DTSTAMP' in ics and ics.count('BEGIN:VEVENT')==18,(ics.count('BEGIN:VEVENT'),'NaN' in ics))
        # --- 7. reminders linked to loans
        await nav(pg,'reminders'); await pg.wait_for_timeout(300)
        opts=await pg.eval_on_selector_all('#rem-loan option','e=>e.map(x=>x.textContent)')
        ok('reminder loan select filled',len(opts)==3,opts)
        await pg.select_option('#rem-loan',index=1); await pg.wait_for_timeout(100)
        v=[await pg.input_value('#rem-bank'),await pg.input_value('#rem-amount'),await pg.input_value('#rem-day')]
        ok('reminder fields autofilled',v[0]=='Agrobank' and int(v[1])>0 and v[2]=='18',v)
        await pg.click('#rem-add'); await pg.wait_for_timeout(200)
        ok('reminder saved',await pg.evaluate("JSON.parse(localStorage.getItem('kn_reminders_v34')).length")==1)
        # --- 8. receipts with big attachment then encrypted backup (b64 overflow regression)
        big=base64.b64encode(os.urandom(400000)).decode()
        await pg.evaluate("(b)=>{const l=KNC.ledger();l[0].receipt='data:application/pdf;base64,'+b;KNC.saveLedger(l)}",big)
        await nav(pg,'backup'); await pg.wait_for_timeout(300)
        await pg.fill('#bk-pass','correct-horse-battery')
        async with pg.expect_download() as dl: await pg.click('button:has-text("Parol bilan shifrlash")')
        f=await dl.value; enc=await f.path(); size=os.path.getsize(enc)
        ok('encrypted backup with large data works',size>500000 and json.load(open(enc))['format']=='KN-V4.5-AES-GCM',size)
        async with pg.expect_download() as dl: await pg.click('button:has-text("Oddiy JSON eksport")')
        f=await dl.value; plain=await f.path(); pj=json.load(open(plain))
        ok('plain backup covers all stores',all(k in pj['store'] for k in ['kn-v21-loans','kn-v41-payment-ledger','kn_reminders_v34']),list(pj['store'].keys()))
        # clear all then restore encrypted
        before=await pg.evaluate("[KNC.loans().length,KNC.ledger().length]")
        await pg.evaluate("KNC.clearAll()")
        ok('cleared',await pg.evaluate("[KNC.loans().length,KNC.ledger().length,localStorage.getItem('kn_reminders_v34')]")==[0,0,None])
        await nav(pg,'backup'); await pg.wait_for_timeout(200)
        await pg.fill('#bk-pass','correct-horse-battery')
        await pg.set_input_files('input[type=file][accept=".json,.knsafe"]',enc); await pg.wait_for_timeout(800)
        after=await pg.evaluate("[KNC.loans().length,KNC.ledger().length,!!localStorage.getItem('kn_reminders_v34')]")
        ok('encrypted restore round-trip',after==[before[0],before[1],True],(before,after))
        # wrong password
        await nav(pg,'backup'); await pg.fill('#bk-pass','wrong-password-xx')
        n=len(dialogs); await pg.set_input_files('input[type=file][accept=".json,.knsafe"]',enc); await pg.wait_for_timeout(600)
        ok('wrong password rejected',any('Tiklab bo‘lmadi' in d for d in dialogs[n:]),dialogs[n:])
        # --- 9. malicious backup (id with quote) must not execute
        evil={'format':'KN-V4.5','store':{'kn-v21-loans':json.dumps([{"id":"x');window.__pwn=1;('","bank":"Evil","name":"E","principal":1000,"annual":10,"months":3}])}}
        open('/tmp/evil.json','w').write(json.dumps(evil))
        await nav(pg,'backup')
        await pg.set_input_files('input[type=file][accept=".json,.knsafe"]','/tmp/evil.json'); await pg.wait_for_timeout(500)
        await nav(pg,'loans'); await pg.wait_for_timeout(300)
        await pg.click('#savedbanks [data-kn-act="schedule"]'); await pg.wait_for_timeout(200)
        ok('no injection via loan id',await pg.evaluate('window.__pwn')is None)
        # --- 10. day theme reminders readable + screenshots
        await pg.evaluate("localStorage.setItem('kn_theme','day');document.documentElement.dataset.knTheme='day'")
        await nav(pg,'reminders'); await pg.wait_for_timeout(200)
        col=await pg.evaluate("getComputedStyle(document.querySelector('#kn-reminders>h2')).color")
        ok('reminders heading dark in day theme',col in('rgb(18, 45, 77)',),col)
        await pg.screenshot(path='s4_reminders_day.png')
        await pg.evaluate("localStorage.removeItem('kn_theme');document.documentElement.dataset.knTheme='night'")
        # --- 11. every nav page opens without errors
        await pg.evaluate("KNC.clearAll()"); await pg.reload(); await pg.wait_for_timeout(300)
        pages=await pg.eval_on_selector_all('#nav button[data-page]','els=>els.map(e=>e.dataset.page)')
        bad=[]
        for pgname in pages:
            n0=len(errs)
            await pg.evaluate("(p)=>document.querySelector('#nav button[data-page=\"'+p+'\"]').click()",pgname); await pg.wait_for_timeout(150)
            empty=await pg.evaluate("document.getElementById('detail').innerText.trim().length")
            if len(errs)>n0 or (pgname!='dashboard' and empty<5): bad.append((pgname,errs[n0:],empty))
        ok('all nav pages render without errors',not bad,bad)
        await pg.screenshot(path='s5_last.png')
        ok('no page errors overall',not errs,errs[:5])
        print('SUMMARY',sum(1 for _,c in res if c),'/',len(res))
        await b.close()
asyncio.run(main())
