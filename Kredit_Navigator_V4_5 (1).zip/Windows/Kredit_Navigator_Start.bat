@echo off
rem Veb-versiyani standart brauzerda ochadi (EXE emas).
start "" "%~dp0..\web\index.html"
